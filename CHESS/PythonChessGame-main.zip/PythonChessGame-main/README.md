# PythonChessGame
A complete chess game made in python. I'm using some techniques from https://github.com/AlejoG10/python-chess-ai-yt like the changing colors feature.

This project is a base one that i'm using to study AI, as i'm developing one to the game. However, you can clone the repository and use as you please. Just make sure to credit the original creator os some of the features.
